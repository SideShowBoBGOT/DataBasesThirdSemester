Files in this directory contain surnames that have had all vowels normalized to ASCII-7.
All non-ASCII consonants have been retained.

For files with vowels in non-normalized UTF-8, see the non-normalized directory. However, 
most databases supplying surnames have them already in normalized form,
and as a result only a few language files are available in non-normalized form.